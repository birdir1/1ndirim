import 'package:flutter/material.dart';

/// 1ndirim App Color Palette
/// Kaynak: https://colorhunt.co/palette/fff2c6fff8deaac4f58ca9ff
class AppColors {
  // Light Theme
  static const backgroundLight = Color(0xFFFFF2C6);
  static const surfaceLight = Color(0xFFFFF8DE);
  static const primaryLight = Color(0xFFAAC4F5);
  static const secondaryLight = Color(0xFF8CA9FF);
  static const textPrimaryLight = Color(0xFF1F2937);
  static const textSecondaryLight = Color(0xFF6B7280);

  // Dark Theme
  static const backgroundDark = Color(0xFF0F172A);
  static const surfaceDark = Color(0xFF1E293B);
  static const primaryDark = Color(0xFF8CA9FF);
  static const secondaryDark = Color(0xFFAAC4F5);
  static const textPrimaryDark = Color(0xFFF8FAFC);
  static const textSecondaryDark = Color(0xFF94A3B8);

  // Semantic Colors
  static const success = Color(0xFF22C55E);
  static const error = Color(0xFFEF4444);
  static const warning = Color(0xFFF59E0B);

  // Helper methods
  static Color background(bool isDark) =>
      isDark ? backgroundDark : backgroundLight;
  static Color surface(bool isDark) => isDark ? surfaceDark : surfaceLight;
  static Color primary(bool isDark) => isDark ? primaryDark : primaryLight;
  static Color secondary(bool isDark) =>
      isDark ? secondaryDark : secondaryLight;
  static Color textPrimary(bool isDark) =>
      isDark ? textPrimaryDark : textPrimaryLight;
  static Color textSecondary(bool isDark) =>
      isDark ? textSecondaryDark : textSecondaryLight;
}
