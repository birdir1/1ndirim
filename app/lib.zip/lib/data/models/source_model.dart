import 'package:flutter/material.dart';

/// Banka/Operator Model
class SourceModel {
  final String id;
  final String name;
  final String type; // 'bank' or 'operator'
  final String iconName; // Material icon name
  final int iconColorValue;
  bool isSelected;

  SourceModel({
    required this.id,
    required this.name,
    required this.type,
    required this.iconName,
    required this.iconColorValue,
    this.isSelected = false,
  });

  Color get iconColor => Color(iconColorValue);

  // Tüm bankalar ve operatörler
  static List<SourceModel> defaultSources = [
    // Kamu Bankaları
    SourceModel(
      id: 'ziraat',
      name: 'Ziraat Bankası',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF16A34A, // green
    ),
    SourceModel(
      id: 'halkbank',
      name: 'Halkbank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF2563EB, // blue
    ),
    SourceModel(
      id: 'vakifbank',
      name: 'VakıfBank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF9333EA, // purple
    ),
    
    // Özel Bankalar
    SourceModel(
      id: 'akbank',
      name: 'Akbank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFFDC2626, // red
    ),
    SourceModel(
      id: 'yapikredi',
      name: 'Yapı Kredi',
      type: 'bank',
      iconName: 'credit_card',
      iconColorValue: 0xFF9333EA, // purple
    ),
    SourceModel(
      id: 'isbank',
      name: 'İş Bankası',
      type: 'bank',
      iconName: 'account_balance_wallet',
      iconColorValue: 0xFF2563EB, // blue
    ),
    SourceModel(
      id: 'garanti',
      name: 'Garanti BBVA',
      type: 'bank',
      iconName: 'payments',
      iconColorValue: 0xFF16A34A, // green
    ),
    SourceModel(
      id: 'qnbfinansbank',
      name: 'QNB Finansbank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF0D9488, // teal
    ),
    SourceModel(
      id: 'denizbank',
      name: 'DenizBank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF38BDF8, // light blue
    ),
    SourceModel(
      id: 'teb',
      name: 'TEB',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFFEA580C, // orange
    ),
    SourceModel(
      id: 'ingbank',
      name: 'ING Bank',
      type: 'bank',
      iconName: 'savings',
      iconColorValue: 0xFFEA580C, // orange
    ),
    SourceModel(
      id: 'sekerbank',
      name: 'Şekerbank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFFCA8A04, // yellow
    ),
    SourceModel(
      id: 'fibabanka',
      name: 'Fibabanka',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFFEF4444, // red
    ),
    SourceModel(
      id: 'anadolubank',
      name: 'Anadolubank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF9333EA, // purple
    ),
    SourceModel(
      id: 'alternatifbank',
      name: 'Alternatif Bank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF2563EB, // blue
    ),
    SourceModel(
      id: 'odeabank',
      name: 'OdeaBank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF16A34A, // green
    ),
    SourceModel(
      id: 'icbc',
      name: 'ICBC Turkey Bank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFFDC2626, // red
    ),
    SourceModel(
      id: 'burganbank',
      name: 'Burgan Bank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF0D9488, // teal
    ),
    SourceModel(
      id: 'turkishbank',
      name: 'Turkish Bank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF38BDF8, // light blue
    ),
    SourceModel(
      id: 'hsbc',
      name: 'HSBC Türkiye',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFFDC2626, // red
    ),
    
    // Katılım Bankaları
    SourceModel(
      id: 'kuveytturk',
      name: 'Kuveyt Türk',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFFCA8A04, // yellow
    ),
    SourceModel(
      id: 'albarakaturk',
      name: 'Albaraka Türk',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF16A34A, // green
    ),
    SourceModel(
      id: 'turkiyefinans',
      name: 'Türkiye Finans',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF2563EB, // blue
    ),
    SourceModel(
      id: 'vakifkatilim',
      name: 'Vakıf Katılım',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF9333EA, // purple
    ),
    SourceModel(
      id: 'ziraatkatilim',
      name: 'Ziraat Katılım',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF16A34A, // green
    ),
    SourceModel(
      id: 'emlakkatilim',
      name: 'Emlak Katılım',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFFEF4444, // red
    ),
    
    // Dijital Bankalar
    SourceModel(
      id: 'enpara',
      name: 'Enpara',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF0D9488, // teal
    ),
    SourceModel(
      id: 'cepteteb',
      name: 'CEPTETEB',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFFEA580C, // orange
    ),
    SourceModel(
      id: 'hayatfinans',
      name: 'Hayat Finans',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF38BDF8, // light blue
    ),
    SourceModel(
      id: 'tombank',
      name: 'TOM Bank',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF9333EA, // purple
    ),
    SourceModel(
      id: 'nkolay',
      name: 'N Kolay',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF2563EB, // blue
    ),
    SourceModel(
      id: 'papara',
      name: 'Papara',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFF16A34A, // green
    ),
    SourceModel(
      id: 'paycell',
      name: 'Paycell',
      type: 'bank',
      iconName: 'account_balance',
      iconColorValue: 0xFFDC2626, // red
    ),
    
    // Ana Operatörler
    SourceModel(
      id: 'turkcell',
      name: 'Turkcell',
      type: 'operator',
      iconName: 'cell_tower',
      iconColorValue: 0xFFCA8A04, // yellow
    ),
    SourceModel(
      id: 'vodafone',
      name: 'Vodafone',
      type: 'operator',
      iconName: 'signal_cellular_alt',
      iconColorValue: 0xFFEF4444, // red
    ),
    SourceModel(
      id: 'turktelekom',
      name: 'Türk Telekom',
      type: 'operator',
      iconName: 'router',
      iconColorValue: 0xFF38BDF8, // light blue
    ),
    
    // MVNO - Türk Telekom Altyapısı
    SourceModel(
      id: 'bimcell',
      name: 'BİMcell',
      type: 'operator',
      iconName: 'signal_cellular_alt',
      iconColorValue: 0xFF38BDF8, // light blue
    ),
    SourceModel(
      id: 'pttcell',
      name: 'PTTcell',
      type: 'operator',
      iconName: 'signal_cellular_alt',
      iconColorValue: 0xFF38BDF8, // light blue
    ),
    SourceModel(
      id: 'pttmobil',
      name: 'PttMobil',
      type: 'operator',
      iconName: 'signal_cellular_alt',
      iconColorValue: 0xFF38BDF8, // light blue
    ),
    SourceModel(
      id: 'netgsm',
      name: 'Netgsm',
      type: 'operator',
      iconName: 'signal_cellular_alt',
      iconColorValue: 0xFF38BDF8, // light blue
    ),
    SourceModel(
      id: 'ttmobil',
      name: 'TT Mobil',
      type: 'operator',
      iconName: 'signal_cellular_alt',
      iconColorValue: 0xFF38BDF8, // light blue
    ),
    
    // MVNO - Vodafone Altyapısı
    SourceModel(
      id: 'kablomobil',
      name: 'KabloMobil',
      type: 'operator',
      iconName: 'signal_cellular_alt',
      iconColorValue: 0xFFEF4444, // red
    ),
    SourceModel(
      id: 'teknosacell',
      name: 'Teknosacell',
      type: 'operator',
      iconName: 'signal_cellular_alt',
      iconColorValue: 0xFFEF4444, // red
    ),
    SourceModel(
      id: 'vestelcell',
      name: 'Vestelcell',
      type: 'operator',
      iconName: 'signal_cellular_alt',
      iconColorValue: 0xFFEF4444, // red
    ),
  ];
}
