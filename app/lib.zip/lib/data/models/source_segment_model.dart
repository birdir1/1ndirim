import 'package:flutter/material.dart';

/// Banka/Operatör Alt Segment Modeli
class SourceSegmentModel {
  final String id;
  final String name;
  bool isSelected;

  SourceSegmentModel({
    required this.id,
    required this.name,
    this.isSelected = false,
  });
}

/// Kaynak (Banka/Operatör) Modeli - Alt segmentlerle
class SourceWithSegmentsModel {
  final String id;
  final String name;
  final String type; // 'bank' or 'operator'
  final String iconName;
  final int iconColorValue;
  bool isSelected;
  bool isExpanded;
  List<SourceSegmentModel> segments;

  SourceWithSegmentsModel({
    required this.id,
    required this.name,
    required this.type,
    required this.iconName,
    required this.iconColorValue,
    this.isSelected = false,
    this.isExpanded = false,
    required this.segments,
  });

  Color get iconColor => Color(iconColorValue);

  // Tüm bankalar ve operatörler - alt segmentlerle
  static List<SourceWithSegmentsModel> getAllSourcesWithSegments() {
    return [
      // KAMU BANKALARI
      SourceWithSegmentsModel(
        id: 'ziraat',
        name: 'Ziraat Bankası',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF16A34A,
        segments: [
          SourceSegmentModel(id: 'ziraat_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'ziraat_gold', name: 'Gold Kart'),
          SourceSegmentModel(id: 'ziraat_platinum', name: 'Platinum Kart'),
          SourceSegmentModel(id: 'ziraat_world', name: 'World Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'halkbank',
        name: 'Halkbank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF2563EB,
        segments: [
          SourceSegmentModel(id: 'halkbank_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'halkbank_gold', name: 'Gold Kart'),
          SourceSegmentModel(id: 'halkbank_platinum', name: 'Platinum Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'vakifbank',
        name: 'VakıfBank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF9333EA,
        segments: [
          SourceSegmentModel(id: 'vakifbank_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'vakifbank_gold', name: 'Gold Kart'),
          SourceSegmentModel(id: 'vakifbank_platinum', name: 'Platinum Kart'),
          SourceSegmentModel(id: 'vakifbank_world', name: 'World Kart'),
        ],
      ),

      // ÖZEL BANKALAR
      SourceWithSegmentsModel(
        id: 'akbank',
        name: 'Akbank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFFDC2626,
        segments: [
          SourceSegmentModel(id: 'akbank_axess', name: 'Axess Kart'),
          SourceSegmentModel(id: 'akbank_advantage', name: 'Advantage Kart'),
          SourceSegmentModel(id: 'akbank_platinum', name: 'Platinum Kart'),
          SourceSegmentModel(id: 'akbank_world', name: 'World Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'yapikredi',
        name: 'Yapı Kredi',
        type: 'bank',
        iconName: 'credit_card',
        iconColorValue: 0xFF9333EA,
        segments: [
          SourceSegmentModel(id: 'yapikredi_world', name: 'World Kart'),
          SourceSegmentModel(id: 'yapikredi_platinum', name: 'Platinum Kart'),
          SourceSegmentModel(id: 'yapikredi_gold', name: 'Gold Kart'),
          SourceSegmentModel(id: 'yapikredi_classic', name: 'Classic Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'isbank',
        name: 'İş Bankası',
        type: 'bank',
        iconName: 'account_balance_wallet',
        iconColorValue: 0xFF2563EB,
        segments: [
          SourceSegmentModel(id: 'isbank_maximum', name: 'Maximum Kart'),
          SourceSegmentModel(id: 'isbank_platinum', name: 'Platinum Kart'),
          SourceSegmentModel(id: 'isbank_gold', name: 'Gold Kart'),
          SourceSegmentModel(id: 'isbank_classic', name: 'Classic Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'garanti',
        name: 'Garanti BBVA',
        type: 'bank',
        iconName: 'payments',
        iconColorValue: 0xFF16A34A,
        segments: [
          SourceSegmentModel(id: 'garanti_bonus', name: 'Bonus Kart'),
          SourceSegmentModel(id: 'garanti_shopfly', name: 'Shop&Fly'),
          SourceSegmentModel(id: 'garanti_genc', name: 'Genç Kart'),
          SourceSegmentModel(id: 'garanti_platinum', name: 'Platinum Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'qnbfinansbank',
        name: 'QNB Finansbank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF0D9488,
        segments: [
          SourceSegmentModel(id: 'qnb_cardfinans', name: 'CardFinans'),
          SourceSegmentModel(id: 'qnb_advantage', name: 'Advantage Kart'),
          SourceSegmentModel(id: 'qnb_platinum', name: 'Platinum Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'denizbank',
        name: 'DenizBank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF38BDF8,
        segments: [
          SourceSegmentModel(id: 'denizbank_denizcard', name: 'DenizCard'),
          SourceSegmentModel(id: 'denizbank_platinum', name: 'Platinum Kart'),
          SourceSegmentModel(id: 'denizbank_gold', name: 'Gold Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'teb',
        name: 'TEB',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFFEA580C,
        segments: [
          SourceSegmentModel(id: 'teb_advantage', name: 'Advantage Kart'),
          SourceSegmentModel(id: 'teb_platinum', name: 'Platinum Kart'),
          SourceSegmentModel(id: 'teb_gold', name: 'Gold Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'ingbank',
        name: 'ING Bank',
        type: 'bank',
        iconName: 'savings',
        iconColorValue: 0xFFEA580C,
        segments: [
          SourceSegmentModel(id: 'ing_advantage', name: 'Advantage Kart'),
          SourceSegmentModel(id: 'ing_platinum', name: 'Platinum Kart'),
          SourceSegmentModel(id: 'ing_gold', name: 'Gold Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'sekerbank',
        name: 'Şekerbank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFFCA8A04,
        segments: [
          SourceSegmentModel(id: 'sekerbank_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'sekerbank_gold', name: 'Gold Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'fibabanka',
        name: 'Fibabanka',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFFEF4444,
        segments: [
          SourceSegmentModel(id: 'fibabanka_advantage', name: 'Advantage Kart'),
          SourceSegmentModel(id: 'fibabanka_platinum', name: 'Platinum Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'anadolubank',
        name: 'Anadolubank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF9333EA,
        segments: [
          SourceSegmentModel(id: 'anadolubank_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'anadolubank_gold', name: 'Gold Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'alternatifbank',
        name: 'Alternatif Bank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF2563EB,
        segments: [
          SourceSegmentModel(id: 'alternatif_advantage', name: 'Advantage Kart'),
          SourceSegmentModel(id: 'alternatif_platinum', name: 'Platinum Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'odeabank',
        name: 'OdeaBank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF16A34A,
        segments: [
          SourceSegmentModel(id: 'odeabank_advantage', name: 'Advantage Kart'),
          SourceSegmentModel(id: 'odeabank_platinum', name: 'Platinum Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'icbc',
        name: 'ICBC Turkey Bank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFFDC2626,
        segments: [
          SourceSegmentModel(id: 'icbc_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'icbc_gold', name: 'Gold Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'burganbank',
        name: 'Burgan Bank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF0D9488,
        segments: [
          SourceSegmentModel(id: 'burgan_advantage', name: 'Advantage Kart'),
          SourceSegmentModel(id: 'burgan_platinum', name: 'Platinum Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'turkishbank',
        name: 'Turkish Bank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF38BDF8,
        segments: [
          SourceSegmentModel(id: 'turkishbank_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'turkishbank_gold', name: 'Gold Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'hsbc',
        name: 'HSBC Türkiye',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFFDC2626,
        segments: [
          SourceSegmentModel(id: 'hsbc_advance', name: 'Advance Kart'),
          SourceSegmentModel(id: 'hsbc_premier', name: 'Premier Kart'),
        ],
      ),

      // KATILIM BANKALARI
      SourceWithSegmentsModel(
        id: 'kuveytturk',
        name: 'Kuveyt Türk',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFFCA8A04,
        segments: [
          SourceSegmentModel(id: 'kuveyt_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'kuveyt_gold', name: 'Gold Kart'),
          SourceSegmentModel(id: 'kuveyt_platinum', name: 'Platinum Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'albarakaturk',
        name: 'Albaraka Türk',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF16A34A,
        segments: [
          SourceSegmentModel(id: 'albaraka_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'albaraka_gold', name: 'Gold Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'turkiyefinans',
        name: 'Türkiye Finans',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF2563EB,
        segments: [
          SourceSegmentModel(id: 'turkiyefinans_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'turkiyefinans_gold', name: 'Gold Kart'),
          SourceSegmentModel(id: 'turkiyefinans_platinum', name: 'Platinum Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'vakifkatilim',
        name: 'Vakıf Katılım',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF9333EA,
        segments: [
          SourceSegmentModel(id: 'vakifkatilim_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'vakifkatilim_gold', name: 'Gold Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'ziraatkatilim',
        name: 'Ziraat Katılım',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF16A34A,
        segments: [
          SourceSegmentModel(id: 'ziraatkatilim_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'ziraatkatilim_gold', name: 'Gold Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'emlakkatilim',
        name: 'Emlak Katılım',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFFEF4444,
        segments: [
          SourceSegmentModel(id: 'emlakkatilim_classic', name: 'Classic Kart'),
          SourceSegmentModel(id: 'emlakkatilim_gold', name: 'Gold Kart'),
        ],
      ),

      // DİJİTAL BANKALAR
      SourceWithSegmentsModel(
        id: 'enpara',
        name: 'Enpara',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF0D9488,
        segments: [
          SourceSegmentModel(id: 'enpara_digital', name: 'Dijital Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'cepteteb',
        name: 'CEPTETEB',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFFEA580C,
        segments: [
          SourceSegmentModel(id: 'cepteteb_digital', name: 'Dijital Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'hayatfinans',
        name: 'Hayat Finans',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF38BDF8,
        segments: [
          SourceSegmentModel(id: 'hayatfinans_digital', name: 'Dijital Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'tombank',
        name: 'TOM Bank',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF9333EA,
        segments: [
          SourceSegmentModel(id: 'tombank_digital', name: 'Dijital Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'nkolay',
        name: 'N Kolay',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF2563EB,
        segments: [
          SourceSegmentModel(id: 'nkolay_digital', name: 'Dijital Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'papara',
        name: 'Papara',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFF16A34A,
        segments: [
          SourceSegmentModel(id: 'papara_digital', name: 'Dijital Kart'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'paycell',
        name: 'Paycell',
        type: 'bank',
        iconName: 'account_balance',
        iconColorValue: 0xFFDC2626,
        segments: [
          SourceSegmentModel(id: 'paycell_digital', name: 'Dijital Kart'),
        ],
      ),

      // ANA OPERATÖRLER
      SourceWithSegmentsModel(
        id: 'turkcell',
        name: 'Turkcell',
        type: 'operator',
        iconName: 'cell_tower',
        iconColorValue: 0xFFCA8A04,
        segments: [
          SourceSegmentModel(id: 'turkcell_tl', name: 'TL Tarifeler'),
          SourceSegmentModel(id: 'turkcell_red', name: 'Red Tarifeler'),
          SourceSegmentModel(id: 'turkcell_superbox', name: 'SuperBox'),
          SourceSegmentModel(id: 'turkcell_genc', name: 'Genç Tarifeler'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'vodafone',
        name: 'Vodafone',
        type: 'operator',
        iconName: 'signal_cellular_alt',
        iconColorValue: 0xFFEF4444,
        segments: [
          SourceSegmentModel(id: 'vodafone_red', name: 'Red Tarifeler'),
          SourceSegmentModel(id: 'vodafone_freezone', name: 'FreeZone'),
          SourceSegmentModel(id: 'vodafone_platinum', name: 'Platinum'),
          SourceSegmentModel(id: 'vodafone_genc', name: 'Genç Tarifeler'),
        ],
      ),
      SourceWithSegmentsModel(
        id: 'turktelekom',
        name: 'Türk Telekom',
        type: 'operator',
        iconName: 'router',
        iconColorValue: 0xFF38BDF8,
        segments: [
          SourceSegmentModel(id: 'turktelekom_tl', name: 'TL Tarifeler'),
          SourceSegmentModel(id: 'turktelekom_ttnet', name: 'TTNET Paketleri'),
          SourceSegmentModel(id: 'turktelekom_genc', name: 'Genç Tarifeler'),
        ],
      ),

      // MVNO - Türk Telekom Altyapısı
      SourceWithSegmentsModel(
        id: 'bimcell',
        name: 'BİMcell',
        type: 'operator',
        iconName: 'signal_cellular_alt',
        iconColorValue: 0xFF38BDF8,
        segments: [],
      ),
      SourceWithSegmentsModel(
        id: 'pttcell',
        name: 'PTTcell',
        type: 'operator',
        iconName: 'signal_cellular_alt',
        iconColorValue: 0xFF38BDF8,
        segments: [],
      ),
      SourceWithSegmentsModel(
        id: 'pttmobil',
        name: 'PttMobil',
        type: 'operator',
        iconName: 'signal_cellular_alt',
        iconColorValue: 0xFF38BDF8,
        segments: [],
      ),
      SourceWithSegmentsModel(
        id: 'netgsm',
        name: 'Netgsm',
        type: 'operator',
        iconName: 'signal_cellular_alt',
        iconColorValue: 0xFF38BDF8,
        segments: [],
      ),
      SourceWithSegmentsModel(
        id: 'ttmobil',
        name: 'TT Mobil',
        type: 'operator',
        iconName: 'signal_cellular_alt',
        iconColorValue: 0xFF38BDF8,
        segments: [],
      ),

      // MVNO - Vodafone Altyapısı
      SourceWithSegmentsModel(
        id: 'kablomobil',
        name: 'KabloMobil',
        type: 'operator',
        iconName: 'signal_cellular_alt',
        iconColorValue: 0xFFEF4444,
        segments: [],
      ),
      SourceWithSegmentsModel(
        id: 'teknosacell',
        name: 'Teknosacell',
        type: 'operator',
        iconName: 'signal_cellular_alt',
        iconColorValue: 0xFFEF4444,
        segments: [],
      ),
      SourceWithSegmentsModel(
        id: 'vestelcell',
        name: 'Vestelcell',
        type: 'operator',
        iconName: 'signal_cellular_alt',
        iconColorValue: 0xFFEF4444,
        segments: [],
      ),
    ];
  }
}
