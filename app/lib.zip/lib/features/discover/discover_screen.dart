import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/utils/page_transitions.dart';
import '../home/home_screen.dart';
import '../notifications/notifications_screen.dart';
import '../profile/profile_screen.dart';

class DiscoverScreen extends StatelessWidget {
  const DiscoverScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight, // #FFF2C6
      body: SafeArea(
        child: Column(
          children: [
            // Main Content - Centered
            Expanded(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Compass Icon with circular background
                      Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          color: AppColors.textSecondaryLight.withOpacity(0.1), // Gri arka plan
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.explore_outlined, // Pusula simgesi
                          size: 64,
                          color: AppColors.secondaryLight, // #8CA9FF - Açık mavi
                        ),
                      ),
                      const SizedBox(height: 32),

                      // Title
                      Text(
                        'Keşfet yakında',
                        style: AppTextStyles.headline(isDark: false).copyWith(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimaryLight, // #1F2937
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 16),

                      // Description
                      Text(
                        'Tüm kampanyaları tek tek aramana gerek kalmayacak. Bu alan çok yakında açılıyor.',
                        style: AppTextStyles.body(isDark: false).copyWith(
                          fontSize: 16,
                          color: AppColors.textPrimaryLight,
                          height: 1.5,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 40),

                      // Button
                      SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).pushReplacement(
                              SlidePageRoute(
                                child: const HomeScreen(),
                                direction: SlideDirection.left,
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.secondaryLight, // #8CA9FF
                            foregroundColor: AppColors.textPrimaryLight, // #1F2937
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                          ),
                          child: Text(
                            'Şimdilik Ana Sayfa',
                            style: AppTextStyles.button(color: AppColors.textPrimaryLight)
                                .copyWith(fontSize: 16),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // Bottom Navigation Bar
            Container(
              decoration: BoxDecoration(
                color: AppColors.surfaceLight, // #FFF8DE
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: BottomNavigationBar(
                backgroundColor: AppColors.surfaceLight,
                selectedItemColor: AppColors.secondaryLight, // #8CA9FF - Aktif renk
                unselectedItemColor: AppColors.textSecondaryLight, // #6B7280
                type: BottomNavigationBarType.fixed,
                elevation: 0,
                currentIndex: 1, // Keşfet aktif
                onTap: (index) {
                  if (index == 0) {
                    Navigator.of(context).pushReplacement(
                      SlidePageRoute(
                        child: const HomeScreen(),
                        direction: SlideDirection.left,
                      ),
                    );
                  } else if (index == 2) {
                    Navigator.of(context).pushReplacement(
                      SlidePageRoute(
                        child: const NotificationsScreen(),
                        direction: SlideDirection.right,
                      ),
                    );
                  } else if (index == 3) {
                    Navigator.of(context).pushReplacement(
                      SlidePageRoute(
                        child: const ProfileScreen(),
                        direction: SlideDirection.right,
                      ),
                    );
                  }
                },
                items: const [
                  BottomNavigationBarItem(
                    icon: Icon(Icons.view_stream_outlined), // İki yatay çizgi
                    label: 'Akış',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.explore_outlined), // Pusula simgesi
                    label: 'Keşfet',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.notifications_outlined),
                    label: 'Bildirimler',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.person_outline),
                    label: 'Profil',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
