import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../widgets/page_indicator.dart';
import '../widgets/primary_button.dart';

/// Onboarding 1 - Value Proposition
/// "Zaten senin olan fırsatlar."
class ValuePropPage extends StatelessWidget {
  final VoidCallback onNext;
  final bool isDark;

  const ValuePropPage({
    super.key,
    required this.onNext,
    this.isDark = false,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 48),
        color: AppColors.backgroundLight, // #FFF2C6
        child: Column(
          children: [
            // Logo - Top center
            Padding(
              padding: const EdgeInsets.only(top: 32),
              child: Text(
                '1ndirim',
                style: AppTextStyles.title(isDark: isDark).copyWith(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textPrimaryLight, // #1F2937
                ),
              ),
            ),

            const Spacer(),

            // Icon Grid (2x2, direct, no circle)
            _buildIconGrid(),

            const Spacer(),

            // Text Content
            _buildContent(),

            const SizedBox(height: 32),

            // Page Indicator
            const PageIndicator(currentPage: 0, pageCount: 4),

            const SizedBox(height: 24),

            // Button
            PrimaryButton(
              label: 'Devam →',
              onPressed: onNext,
              isDark: isDark,
            ),

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildIconGrid() {
    return GridView.count(
      crossAxisCount: 2,
      mainAxisSpacing: 24,
      crossAxisSpacing: 24,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1.0,
      children: [
        _buildIconBox(Icons.credit_card),
        _buildIconBox(Icons.signal_cellular_alt),
        _buildIconBox(Icons.shopping_bag),
        _buildIconBox(Icons.auto_awesome),
      ],
    );
  }

  Widget _buildIconBox(IconData icon) {
    return Container(
      width: 80,
      height: 80,
      decoration: BoxDecoration(
        color: AppColors.surfaceLight, // #FFF8DE
        borderRadius: BorderRadius.circular(16),
      ),
      child: Icon(
        icon,
        color: AppColors.primaryLight, // #8CA9FF
        size: 40,
      ),
    );
  }

  Widget _buildContent() {
    return Column(
      children: [
        Text(
          'Zaten senin olan fırsatlar.',
          style: AppTextStyles.headline(isDark: isDark).copyWith(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimaryLight, // #1F2937
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 16),
        Text(
          'Banka kartların ve operatörlerinle\nerişebileceğin kampanyaları tek yerde toplar.',
          style: AppTextStyles.bodySecondary(isDark: isDark).copyWith(
            fontSize: 16,
            color: AppColors.textSecondaryLight, // #6B7280
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
