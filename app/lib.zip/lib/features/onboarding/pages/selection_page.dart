import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../data/models/source_model.dart';
import '../widgets/primary_button.dart';
import '../widgets/source_selection_grid.dart';

/// Onboarding 2 - Selection
/// "Ne kullandığını seç."
class SelectionPage extends StatefulWidget {
  final VoidCallback onNext;
  final VoidCallback onBack;
  final Function(List<String>) onSourcesChanged;
  final bool isDark;

  const SelectionPage({
    super.key,
    required this.onNext,
    required this.onBack,
    required this.onSourcesChanged,
    this.isDark = false,
  });

  @override
  State<SelectionPage> createState() => _SelectionPageState();
}

class _SelectionPageState extends State<SelectionPage> {
  late List<SourceModel> _sources;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _sources = SourceModel.defaultSources.map((s) => SourceModel(
      id: s.id,
      name: s.name,
      type: s.type,
      iconName: s.iconName,
      iconColorValue: s.iconColorValue,
      isSelected: false,
    )).toList();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _toggleSource(String id) {
    setState(() {
      final index = _sources.indexWhere((s) => s.id == id);
      if (index != -1) {
        _sources[index].isSelected = !_sources[index].isSelected;
      }
    });
    _notifySourcesChanged();
  }

  void _notifySourcesChanged() {
    final selectedIds = _sources
        .where((s) => s.isSelected)
        .map((s) => s.id)
        .toList();
    widget.onSourcesChanged(selectedIds);
  }

  List<SourceModel> get _filteredSources {
    if (_searchQuery.isEmpty) return _sources;
    return _sources.where((s) {
      return s.name.toLowerCase().contains(_searchQuery.toLowerCase());
    }).toList();
  }

  bool get _hasSelection => _sources.any((s) => s.isSelected);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        color: AppColors.backgroundLight,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 48),
        child: Column(
          children: [
            // Logo (centered)
            Padding(
              padding: const EdgeInsets.only(top: 32),
              child: Text(
                '1ndirim',
                style: AppTextStyles.title(isDark: widget.isDark),
              ),
            ),

            const SizedBox(height: 24),

            // Content
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header
                    Text(
                      'Ne kullandığını seç.',
                      style: AppTextStyles.headline(isDark: widget.isDark),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Hangi banka ve operatörlere sahipsen\nsadece onları seçmen yeterli.',
                      style: AppTextStyles.bodySecondary(isDark: widget.isDark),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),

                    // Search bar
                    Container(
                      height: 48,
                      decoration: BoxDecoration(
                        color: AppColors.surfaceLight, // #FFF8DE
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: TextField(
                        controller: _searchController,
                        style: AppTextStyles.body(isDark: widget.isDark),
                        decoration: InputDecoration(
                          hintText: 'Ara...',
                          hintStyle: AppTextStyles.bodySecondary(isDark: widget.isDark),
                          prefixIcon: Icon(
                            Icons.search,
                            color: AppColors.textSecondary(widget.isDark),
                            size: 20,
                          ),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 12,
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {
                            _searchQuery = value;
                          });
                        },
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Grid (3x3 - daha küçük simgeler)
                    SourceSelectionGrid(
                      sources: _filteredSources,
                      onToggle: _toggleSource,
                      isDark: widget.isDark,
                      crossAxisCount: 3,
                    ),

                    const SizedBox(height: 24),

                    // Helper Text
                    Text(
                      'Kart bilgisi veya şifre istemiyoruz.',
                      style: AppTextStyles.small(isDark: widget.isDark),
                      textAlign: TextAlign.center,
                    ),

                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),

            // Button
            PrimaryButton(
              label: 'Devam →',
              onPressed: _hasSelection ? widget.onNext : null,
              isDark: widget.isDark,
              isEnabled: _hasSelection,
            ),

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
