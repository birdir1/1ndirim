import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../data/models/source_model.dart';

/// Banka/Operatör seçim gridi
class SourceSelectionGrid extends StatelessWidget {
  final List<SourceModel> sources;
  final Function(String) onToggle;
  final bool isDark;
  final int crossAxisCount;

  const SourceSelectionGrid({
    super.key,
    required this.sources,
    required this.onToggle,
    this.isDark = false,
    this.crossAxisCount = 3,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: EdgeInsets.zero,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        childAspectRatio: 0.85,
      ),
      itemCount: sources.length,
      itemBuilder: (context, index) {
        final source = sources[index];
        return _SourceCard(
          source: source,
          isDark: isDark,
          onTap: () => onToggle(source.id),
        );
      },
    );
  }
}

class _SourceCard extends StatelessWidget {
  final SourceModel source;
  final bool isDark;
  final VoidCallback onTap;

  const _SourceCard({
    required this.source,
    required this.isDark,
    required this.onTap,
  });

  IconData _getIconData(String iconName) {
    switch (iconName) {
      case 'account_balance':
        return Icons.account_balance;
      case 'payments':
        return Icons.payments;
      case 'account_balance_wallet':
        return Icons.account_balance_wallet;
      case 'cell_tower':
        return Icons.cell_tower;
      case 'signal_cellular_alt':
        return Icons.signal_cellular_alt;
      case 'router':
        return Icons.router;
      case 'credit_card':
        return Icons.credit_card;
      case 'savings':
        return Icons.savings;
      default:
        return Icons.business;
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Card - daha küçük
            Container(
              height: 60,
              decoration: BoxDecoration(
                color: source.isSelected
                    ? AppColors.primary(isDark) // #8CA9FF
                    : AppColors.surfaceLight, // #FFF8DE
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: source.isSelected
                      ? AppColors.primary(isDark)
                      : Colors.transparent,
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 4,
                    offset: const Offset(0, 1),
                  ),
                ],
              ),
              child: Stack(
                children: [
                  Center(
                    child: Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: source.iconColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        _getIconData(source.iconName),
                        color: source.iconColor,
                        size: 18, // Daha küçük simge
                      ),
                    ),
                  ),
                  // Checkmark - daha küçük
                  if (source.isSelected)
                    Positioned(
                      top: 4,
                      right: 4,
                      child: Icon(
                        Icons.check_circle,
                        color: AppColors.primary(isDark),
                        size: 16,
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 4),
            // Label - daha küçük font
            Text(
              source.name,
              style: AppTextStyles.small(isDark: isDark).copyWith(
                fontSize: 10,
                fontWeight:
                    source.isSelected ? FontWeight.w600 : FontWeight.w500,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
