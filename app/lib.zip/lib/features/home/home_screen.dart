import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/utils/page_transitions.dart';
import 'campaign_detail_screen.dart';
import '../discover/discover_screen.dart';
import '../notifications/notifications_screen.dart';
import '../profile/profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _selectedFilter = 'Tümü';

  final List<Map<String, dynamic>> _opportunities = [
    {
      'title': '%50 İndirim',
      'subtitle': 'Netflix / Yapı Kredi',
      'icon': Icons.play_arrow,
      'iconColor': Colors.red,
      'iconBgColor': Colors.red.shade50,
      'tags': ['Online', 'Son 2 gün'],
    },
    {
      'title': '1 Kahve Hediye',
      'subtitle': 'Starbucks / Akbank',
      'icon': Icons.local_cafe,
      'iconColor': Colors.green.shade600,
      'iconBgColor': Colors.green.shade50,
      'tags': ['Mağazada', 'Son 5 gün'],
    },
    {
      'title': '200 TL Puan',
      'subtitle': 'Trendyol / Garanti BBVA',
      'icon': Icons.shopping_bag,
      'iconColor': Colors.orange,
      'iconBgColor': Colors.orange.shade50,
      'tags': ['Online'],
    },
    {
      'title': '%20 İndirim',
      'subtitle': 'THY / Turkcell Platinum',
      'icon': Icons.flight,
      'iconColor': Colors.blue,
      'iconBgColor': Colors.blue.shade50,
      'tags': ['Yurt Dışı', 'Son 1 hafta'],
    },
  ];

  final List<Map<String, dynamic>> _filters = [
    {'name': 'Tümü', 'color': null},
    {'name': 'Akbank', 'color': Colors.red},
    {'name': 'Garanti BBVA', 'color': Colors.green},
    {'name': 'Turkcell', 'color': Colors.yellow.shade400},
    {'name': 'Yapı Kredi', 'color': Colors.blue.shade600},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight, // #FFF2C6
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 16, 24, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '1ndirim',
                          style: AppTextStyles.title(isDark: false).copyWith(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimaryLight,
                            letterSpacing: -0.01,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Seçtiklerine göre güncel fırsatlar',
                          style: AppTextStyles.bodySecondary(isDark: false).copyWith(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: const Color(0xFF6B6B88),
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pushReplacement(
                        SlidePageRoute(
                          child: const ProfileScreen(),
                          direction: SlideDirection.right,
                        ),
                      );
                    },
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.5),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: AppColors.textPrimaryLight.withOpacity(0.1),
                          width: 1,
                        ),
                      ),
                      child: const Icon(
                        Icons.account_circle,
                        size: 24,
                        color: AppColors.textPrimaryLight,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Filter Bar
            SizedBox(
              height: 48,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                itemCount: _filters.length,
                itemBuilder: (context, index) {
                  final filter = _filters[index];
                  final isActive = _selectedFilter == filter['name'];
                  
                  return Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          _selectedFilter = filter['name'] as String;
                        });
                      },
                      child: Container(
                        height: 36,
                        padding: EdgeInsets.symmetric(
                          horizontal: filter['color'] != null ? 10 : 16,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: isActive
                              ? AppColors.secondaryLight // #8CA9FF
                              : Colors.white,
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 4,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (filter['color'] != null) ...[
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: filter['color'] as Color,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 6),
                            ],
                            Text(
                              filter['name'] as String,
                              style: AppTextStyles.body(isDark: false).copyWith(
                                fontSize: 13,
                                fontWeight: isActive
                                    ? FontWeight.w600
                                    : FontWeight.w500,
                                color: isActive
                                    ? Colors.white
                                    : AppColors.textPrimaryLight,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            // Main Feed
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(24, 4, 24, 80),
                itemCount: _opportunities.length,
                itemBuilder: (context, index) {
                  final opportunity = _opportunities[index];
                  return _buildOpportunityCard(opportunity);
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.9),
            border: Border(
              top: BorderSide(
                color: Colors.grey.shade100,
                width: 1,
              ),
            ),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.03),
                blurRadius: 20,
                offset: const Offset(0, -4),
              ),
            ],
          ),
          child: Container(
            padding: const EdgeInsets.only(top: 8, bottom: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildNavItem(
                  icon: Icons.view_stream,
                  label: 'Akış',
                  isActive: true,
                  onTap: () {},
                ),
                _buildNavItem(
                  icon: Icons.explore_outlined,
                  label: 'Keşfet',
                  isActive: false,
                  onTap: () {
                    Navigator.of(context).pushReplacement(
                      SlidePageRoute(
                        child: const DiscoverScreen(),
                        direction: SlideDirection.right,
                      ),
                    );
                  },
                ),
                _buildNavItem(
                  icon: Icons.notifications_outlined,
                  label: 'Bildirimler',
                  isActive: false,
                  onTap: () {
                    Navigator.of(context).pushReplacement(
                      SlidePageRoute(
                        child: const NotificationsScreen(),
                        direction: SlideDirection.right,
                      ),
                    );
                  },
                ),
                _buildNavItem(
                  icon: Icons.person_outline,
                  label: 'Profil',
                  isActive: false,
                  onTap: () {
                    Navigator.of(context).pushReplacement(
                      SlidePageRoute(
                        child: const ProfileScreen(),
                        direction: SlideDirection.right,
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildOpportunityCard(Map<String, dynamic> opportunity) {
    return InkWell(
      onTap: () {
        Navigator.of(context).push(
          SlidePageRoute(
            child: CampaignDetailScreen(
              title: opportunity['title'] as String,
              description: opportunity['subtitle'] as String,
              detailText: 'Bu kampanyayı kullanmak için ilgili kartınızla alışveriş yapmanız yeterli.',
              logoColor: opportunity['iconColor'] as Color,
            ),
            direction: SlideDirection.right,
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 12,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Icon Box
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: opportunity['iconBgColor'] as Color,
                shape: BoxShape.circle,
              ),
              child: Icon(
                opportunity['icon'] as IconData,
                size: 24,
                color: opportunity['iconColor'] as Color,
              ),
            ),
            const SizedBox(width: 12),
            // Content
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    opportunity['title'] as String,
                    style: AppTextStyles.title(isDark: false).copyWith(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimaryLight,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 3),
                  Text(
                    opportunity['subtitle'] as String,
                    style: AppTextStyles.bodySecondary(isDark: false).copyWith(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: const Color(0xFF6B6B88),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 12),
                  // Tags
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: (opportunity['tags'] as List<String>)
                        .map((tag) => Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFFF0F0F5),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Text(
                                tag,
                                style: AppTextStyles.caption(isDark: false).copyWith(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  color: const Color(0xFF6B6B88),
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ))
                        .toList(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem({
    required IconData icon,
    required String label,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 26,
              color: isActive
                  ? AppColors.secondaryLight // #8CA9FF
                  : const Color(0xFF8A8A9D),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
                color: isActive
                    ? AppColors.secondaryLight // #8CA9FF
                    : const Color(0xFF8A8A9D),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
