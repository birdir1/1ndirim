import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/utils/page_transitions.dart';
import '../discover/discover_screen.dart';
import '../home/home_screen.dart';
import '../notifications/notifications_screen.dart';
import '../profile/profile_screen.dart';

class CampaignDetailScreen extends StatelessWidget {
  final String title;
  final String description;
  final String detailText;
  final Color logoColor;

  const CampaignDetailScreen({
    super.key,
    required this.title,
    required this.description,
    required this.detailText,
    required this.logoColor,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight, // #FFF2C6
      appBar: AppBar(
        backgroundColor: AppColors.backgroundLight,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: AppColors.textPrimaryLight, // #1F2937
            size: 20,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        centerTitle: true,
        title: Text(
          '1ndirim',
          style: AppTextStyles.title(isDark: false).copyWith(
            fontSize: 24,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimaryLight, // #1F2937
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(
              Icons.share_outlined,
              color: AppColors.textPrimaryLight,
              size: 24,
            ),
            onPressed: () {
              // Share action
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Logo
            Center(
              child: Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: logoColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.account_balance,
                  color: logoColor,
                  size: 24,
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Title
            Text(
              title,
              style: AppTextStyles.headline(isDark: false).copyWith(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimaryLight, // #1F2937
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),

            // Description
            Text(
              description,
              style: AppTextStyles.bodySecondary(isDark: false).copyWith(
                fontSize: 16,
                color: AppColors.textSecondaryLight, // #6B7280
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),

            // Detail Text
            Text(
              detailText,
              style: AppTextStyles.body(isDark: false).copyWith(
                fontSize: 16,
                color: AppColors.textPrimaryLight, // #1F2937
                height: 1.5,
              ),
            ),
            const SizedBox(height: 32),

            // Use Button
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: () {
                  // Use campaign action
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryLight, // #8CA9FF
                  foregroundColor: AppColors.textPrimaryLight, // #1F2937
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  'Kullan',
                  style: AppTextStyles.button(color: AppColors.textPrimaryLight)
                      .copyWith(fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppColors.surfaceLight, // #FFF8DE
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: BottomNavigationBar(
          backgroundColor: AppColors.surfaceLight,
          selectedItemColor: AppColors.primaryLight, // #8CA9FF
          unselectedItemColor: AppColors.textSecondaryLight, // #6B7280
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          currentIndex: 0,
          onTap: (index) {
            if (index == 0) {
              Navigator.of(context).popUntil((route) => route.isFirst);
            } else if (index == 1) {
              Navigator.of(context).pushReplacement(
                SlidePageRoute(
                  child: const DiscoverScreen(),
                  direction: SlideDirection.right,
                ),
              );
            } else if (index == 2) {
              Navigator.of(context).pushReplacement(
                SlidePageRoute(
                  child: const NotificationsScreen(),
                  direction: SlideDirection.right,
                ),
              );
            } else if (index == 3) {
              Navigator.of(context).pushReplacement(
                SlidePageRoute(
                  child: const ProfileScreen(),
                  direction: SlideDirection.right,
                ),
              );
            }
          },
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Ana Sayfa',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.search),
              label: 'Ara',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.notifications),
              label: 'Bildirimler',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Profil',
            ),
          ],
        ),
      ),
    );
  }
}
