import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/utils/page_transitions.dart';
import '../home/home_screen.dart';
import '../discover/discover_screen.dart';
import '../profile/profile_screen.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight, // #FFF2C6
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(width: 48), // Spacer for balance
                  Expanded(
                    child: Center(
                      child: Text(
                        'Bildirimler',
                        style: AppTextStyles.title(isDark: false).copyWith(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimaryLight,
                          letterSpacing: -0.015,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 48), // Spacer for balance
                ],
              ),
            ),

            // Main Content - Empty State
            Expanded(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Icon with blur effect
                      Stack(
                        alignment: Alignment.center,
                        children: [
                          // Blur background
                          Container(
                            width: 128,
                            height: 128,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.4),
                              shape: BoxShape.circle,
                            ),
                          ),
                          // Main icon container
                          Container(
                            width: 96,
                            height: 96,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 4,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                              border: Border.all(
                                color: Colors.white.withOpacity(0.5),
                                width: 4,
                              ),
                            ),
                            child: const Icon(
                              Icons.notifications,
                              size: 48,
                              color: AppColors.secondaryLight, // #8CA9FF
                            ),
                          ),
                          // Small schedule icon badge
                          Positioned(
                            top: 0,
                            right: 0,
                            child: Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                color: AppColors.backgroundLight, // #FFF2C6
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.white,
                                  width: 2,
                                ),
                              ),
                              child: const Icon(
                                Icons.schedule,
                                size: 16,
                                color: Colors.orange,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 32),

                      // Title
                      Text(
                        'Bildirimler yakında',
                        style: AppTextStyles.title(isDark: false).copyWith(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimaryLight,
                          letterSpacing: -0.01,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 12),

                      // Description
                      Text(
                        'Yeni fırsatlar eklendiğinde sadece gerçekten işine yarayanları haber vereceğiz.',
                        style: AppTextStyles.bodySecondary(isDark: false).copyWith(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: const Color(0xFF475569), // slate-700
                          height: 1.5,
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 3,
                      ),
                      const SizedBox(height: 12),

                      // Badge
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.2),
                            width: 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Text(
                              '✨',
                              style: TextStyle(fontSize: 12),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              'Gereksiz bildirim yok.',
                              style: AppTextStyles.caption(isDark: false).copyWith(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: AppColors.secondaryLight.withOpacity(0.8),
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 32),

                      // Button
                      SizedBox(
                        width: 160,
                        height: 44,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).pushReplacement(
                              SlidePageRoute(
                                child: const HomeScreen(),
                                direction: SlideDirection.left,
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.textPrimaryLight.withOpacity(0.05),
                            foregroundColor: AppColors.textPrimaryLight.withOpacity(0.4),
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(24),
                            ),
                          ),
                          child: Text(
                            'Ana Sayfaya Dön',
                            style: AppTextStyles.button(
                              color: AppColors.textPrimaryLight.withOpacity(0.4),
                            ).copyWith(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.015,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // Bottom Navigation Bar
            Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.9),
                border: Border(
                  top: BorderSide(
                    color: const Color(0xFFE7E7F3).withOpacity(0.5),
                    width: 1,
                  ),
                ),
              ),
              child: Container(
                padding: const EdgeInsets.only(top: 8, bottom: 24),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildNavItem(
                      icon: Icons.home_outlined,
                      label: 'Akış',
                      isActive: false,
                      onTap: () {
                        Navigator.of(context).pushReplacement(
                          SlidePageRoute(
                            child: const HomeScreen(),
                            direction: SlideDirection.left,
                          ),
                        );
                      },
                    ),
                    _buildNavItem(
                      icon: Icons.explore_outlined,
                      label: 'Keşfet',
                      isActive: false,
                      onTap: () {
                        Navigator.of(context).pushReplacement(
                          SlidePageRoute(
                            child: const DiscoverScreen(),
                            direction: SlideDirection.left,
                          ),
                        );
                      },
                    ),
                    _buildNavItem(
                      icon: Icons.notifications,
                      label: 'Bildirimler',
                      isActive: true,
                      onTap: () {},
                    ),
                    _buildNavItem(
                      icon: Icons.person_outline,
                      label: 'Profil',
                      isActive: false,
                      onTap: () {
                        Navigator.of(context).pushReplacement(
                          SlidePageRoute(
                            child: const ProfileScreen(),
                            direction: SlideDirection.right,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem({
    required IconData icon,
    required String label,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 28,
              alignment: Alignment.center,
              child: Icon(
                icon,
                size: 26,
                color: isActive
                    ? AppColors.secondaryLight // #8CA9FF
                    : const Color(0xFF94A3B8), // slate-400
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
                color: isActive
                    ? AppColors.secondaryLight // #8CA9FF
                    : const Color(0xFF94A3B8), // slate-400
                letterSpacing: 0.015,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
