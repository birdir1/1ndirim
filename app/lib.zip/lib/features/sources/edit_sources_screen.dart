import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/utils/page_transitions.dart';
import '../../data/models/source_segment_model.dart';
import 'save_confirmation_screen.dart';

class EditSourcesScreen extends StatefulWidget {
  const EditSourcesScreen({super.key});

  @override
  State<EditSourcesScreen> createState() => _EditSourcesScreenState();
}

class _EditSourcesScreenState extends State<EditSourcesScreen> {
  late List<SourceWithSegmentsModel> _sources;
  final Set<String> _expandedIds = {};

  @override
  void initState() {
    super.initState();
    _sources = SourceWithSegmentsModel.getAllSourcesWithSegments();
    // İlk kaynağı açık başlat (Garanti BBVA)
    if (_sources.isNotEmpty) {
      final garantiIndex = _sources.indexWhere((s) => s.id == 'garanti');
      if (garantiIndex != -1) {
        _expandedIds.add(_sources[garantiIndex].id);
      }
    }
  }

  void _toggleExpand(String id) {
    setState(() {
      if (_expandedIds.contains(id)) {
        _expandedIds.remove(id);
      } else {
        _expandedIds.add(id);
      }
    });
  }

  void _toggleSourceSelection(String sourceId) {
    setState(() {
      final source = _sources.firstWhere((s) => s.id == sourceId);
      source.isSelected = !source.isSelected;
      // Eğer kaynak seçiliyse, tüm segmentlerini seç
      if (source.isSelected) {
        for (var segment in source.segments) {
          segment.isSelected = true;
        }
      } else {
        // Eğer kaynak seçili değilse, tüm segmentlerini kaldır
        for (var segment in source.segments) {
          segment.isSelected = false;
        }
      }
    });
  }

  void _toggleSegmentSelection(String sourceId, String segmentId) {
    setState(() {
      final source = _sources.firstWhere((s) => s.id == sourceId);
      final segment = source.segments.firstWhere((s) => s.id == segmentId);
      segment.isSelected = !segment.isSelected;
      
      // Eğer en az bir segment seçiliyse, kaynağı da seç
      final anySelected = source.segments.any((s) => s.isSelected);
      source.isSelected = anySelected;
    });
  }

  void _saveChanges() {
    // Seçili kaynakları ve segmentleri kaydet
    final selectedSources = _sources.where((s) => s.isSelected).map((s) => s.id).toList();
    final selectedSegments = <String>[];
    
    for (var source in _sources) {
      for (var segment in source.segments) {
        if (segment.isSelected) {
          selectedSegments.add(segment.id);
        }
      }
    }
    
    // TODO: SharedPreferences'a kaydet
    // debugPrint('Selected sources: $selectedSources');
    // debugPrint('Selected segments: $selectedSegments');
    
    // Onay ekranına git
    Navigator.of(context).pushReplacement(
      SlidePageRoute(
        child: const SaveConfirmationScreen(),
        direction: SlideDirection.right,
      ),
    );
  }

  IconData _getIconData(String iconName) {
    switch (iconName) {
      case 'account_balance':
        return Icons.account_balance;
      case 'payments':
        return Icons.payments;
      case 'account_balance_wallet':
        return Icons.account_balance_wallet;
      case 'cell_tower':
        return Icons.cell_tower;
      case 'signal_cellular_alt':
        return Icons.signal_cellular_alt;
      case 'router':
        return Icons.router;
      case 'credit_card':
        return Icons.credit_card;
      case 'savings':
        return Icons.savings;
      default:
        return Icons.business;
    }
  }

  List<SourceWithSegmentsModel> get _banks {
    return _sources.where((s) => s.type == 'bank').toList();
  }

  List<SourceWithSegmentsModel> get _operators {
    return _sources.where((s) => s.type == 'operator').toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight, // #FFF2C6
      appBar: AppBar(
        backgroundColor: AppColors.backgroundLight,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: AppColors.textPrimaryLight,
            size: 20,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        centerTitle: true,
        title: Text(
          'Kaynaklarımı Düzenle',
          style: AppTextStyles.title(isDark: false).copyWith(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimaryLight, // #1F2937
          ),
        ),
        actions: [
          TextButton(
            onPressed: _saveChanges,
            child: Text(
              'Kaydet',
              style: AppTextStyles.body(isDark: false).copyWith(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: AppColors.primaryLight, // #8CA9FF
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // BANKALAR Section
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(
                'BANKALAR',
                style: AppTextStyles.small(isDark: false).copyWith(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textSecondaryLight, // #6B7280
                  letterSpacing: 1.2,
                ),
              ),
            ),
            ..._banks.map((source) => _buildSourceCard(source)),
            
            const SizedBox(height: 32),
            
            // OPERATÖRLER Section
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(
                'OPERATÖRLER',
                style: AppTextStyles.small(isDark: false).copyWith(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textSecondaryLight, // #6B7280
                  letterSpacing: 1.2,
                ),
              ),
            ),
            ..._operators.map((source) => _buildSourceCard(source)),
            
            const SizedBox(height: 24),
            
            // Info Text
            Center(
              child: Text(
                'Alt seçimler, sana uygun kampanyaları\ndaha doğru göstermemizi sağlar.',
                style: AppTextStyles.small(isDark: false).copyWith(
                  fontSize: 12,
                  color: AppColors.textSecondaryLight, // #6B7280
                ),
                textAlign: TextAlign.center,
              ),
            ),
            
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _buildSourceCard(SourceWithSegmentsModel source) {
    final isExpanded = _expandedIds.contains(source.id);
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.surfaceLight, // #FFF8DE
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header - Tıklanabilir (sadece alt segmentleri varsa)
          InkWell(
            onTap: source.segments.isNotEmpty ? () => _toggleExpand(source.id) : null,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // Checkbox
                  Checkbox(
                    value: source.isSelected,
                    onChanged: (value) => _toggleSourceSelection(source.id),
                    activeColor: AppColors.primaryLight,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const SizedBox(width: 12),
                  // Icon
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: source.iconColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      _getIconData(source.iconName),
                      color: source.iconColor,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 12),
                  // Name
                  Expanded(
                    child: Text(
                      source.name,
                      style: AppTextStyles.body(isDark: false).copyWith(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: AppColors.textPrimaryLight, // #1F2937
                      ),
                    ),
                  ),
                  // Expand Icon - Sadece alt segmentleri varsa göster
                  if (source.segments.isNotEmpty)
                    Icon(
                      isExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                      color: AppColors.textSecondaryLight,
                      size: 24,
                    ),
                ],
              ),
            ),
          ),
          
          // Segments - Expandable
          if (isExpanded)
            Padding(
              padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
              child: Column(
                children: source.segments.map((segment) {
                  return Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Row(
                      children: [
                        const SizedBox(width: 48), // Checkbox için boşluk
                        Checkbox(
                          value: segment.isSelected,
                          onChanged: (value) => _toggleSegmentSelection(source.id, segment.id),
                          activeColor: AppColors.primaryLight,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            segment.name,
                            style: AppTextStyles.body(isDark: false).copyWith(
                              fontSize: 14,
                              color: AppColors.textPrimaryLight, // #1F2937
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
        ],
      ),
    );
  }
}
